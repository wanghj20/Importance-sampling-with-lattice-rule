import numpy as np


x = np.load('./generator8191.npy')
print(type(x))
print(x.shape)
print(x.dtype)
print(x[:40])
